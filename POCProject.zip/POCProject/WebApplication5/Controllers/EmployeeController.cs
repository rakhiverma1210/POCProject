﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication5.Models;

namespace WebApplication5.Controllers
{
    public class EmployeeController : Controller
    {
         
        public ActionResult Index()
        {
            using (POC_DBEntities Obj = new POC_DBEntities())
            {                
                double pageCount = (double)((decimal)Obj.Employees.Count() / Convert.ToDecimal(4));
                pageCount = (int)Math.Ceiling(pageCount);
                return View(pageCount);
            }
        }
        
        public JsonResult Get_AllEmployee()
        {
            using (POC_DBEntities Obj = new POC_DBEntities())
            {

                //List<Employee> Emp = Obj.Employees.ToList();
                //return Json(Emp, JsonRequestBehavior.AllowGet);                
                var Emp = Get_Employee_Paging(1);                
                return Emp;
            }
        }

        public JsonResult Get_Employee_Paging(int currentPage)
        {
            using (POC_DBEntities Obj = new POC_DBEntities())
            {
                
                int maxRows = 4;
                var result = (from employee in Obj.Employees
                              select employee)
                            .OrderBy(employee => employee.Emp_Id)
                            .Skip((currentPage - 1) * maxRows)
                            .Take(maxRows).ToList();

                List<Employee> Emp = result.ToList();                
                return Json(Emp, JsonRequestBehavior.AllowGet);

                //List<Employee> Emp = Obj.Employees.ToList();
                //return Json(Emp, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult Get_EmployeeById(string Id)
        {
            using (POC_DBEntities Obj = new POC_DBEntities())
            {
                int EmpId = int.Parse(Id);
                return Json(Obj.Employees.Find(EmpId), JsonRequestBehavior.AllowGet);
            }
        }
         
        public string Insert_Employee(Employee Employe)
        {
            if (Employe != null)
            {
                using (POC_DBEntities Obj = new POC_DBEntities())
                {
                    Obj.Employees.Add(Employe);
                    Obj.SaveChanges();
                    return "Employee Added Successfully";
                }
            }
            else
            {
                return "Employee Not Inserted! Try Again";
            }
        }
        
        public string Delete_Employee(Employee Emp)
        {
            if (Emp != null)
            {
                using (POC_DBEntities Obj = new POC_DBEntities())
                {
                    var Emp_ = Obj.Entry(Emp);
                    if (Emp_.State == System.Data.Entity.EntityState.Detached)
                    {
                        Obj.Employees.Attach(Emp);
                        Obj.Employees.Remove(Emp);
                    }
                    Obj.SaveChanges();
                    return "Employee Deleted Successfully";
                }
            }
            else
            {
                return "Employee Not Deleted! Try Again";
            }
        }
       
        public string Update_Employee(Employee Emp)
        {
            if (Emp != null)
            {
                using (POC_DBEntities Obj = new POC_DBEntities())
                {
                    var Emp_ = Obj.Entry(Emp);
                    Employee EmpObj = Obj.Employees.Where(x => x.Emp_Id == Emp.Emp_Id).FirstOrDefault();
                    EmpObj.Emp_Age = Emp.Emp_Age;
                    EmpObj.Emp_City = Emp.Emp_City;
                    EmpObj.Emp_Name = Emp.Emp_Name;
                    Obj.SaveChanges();
                    return "Employee Updated Successfully";
                }
            }
            else
            {
                return "Employee Not Updated! Try Again";
            }
        }
    }
}